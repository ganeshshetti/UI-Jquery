angular.module('app.controllers', [])
  
.controller('homeCtrl', function($scope) {

})
   
.controller('newsCtrl', function($scope) {

})
   
.controller('cloudCtrl', function($scope) {

})
      
.controller('loginCtrl', function($scope) {

})
   
.controller('signupCtrl', function($scope) {

})
   
.controller('pageCtrl', function($scope) {

})
   
.controller('page2Ctrl', function($scope) {

})
 